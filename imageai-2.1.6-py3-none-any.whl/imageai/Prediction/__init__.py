from ..Classification import ImageClassification
from matplotlib.cbook import deprecated


class ImagePrediction(ImageClassification):
    """
    Deprecated! 
    Replaced with 'imageai.Classification.ImageClassification'
    """

    def __call__(self):
        None